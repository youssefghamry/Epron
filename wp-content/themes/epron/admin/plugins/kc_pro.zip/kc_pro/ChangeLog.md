
Version 1.9 / (8 Jul,2018)
============================
- [Fix]: Right-click panel on responsive mode
- [Improved]: Compatible with KingComposer version 2.6

Version 1.7 / (14 nov,2016)
============================
- [Fix]: Do not save when deleting all

Version 1.6 / (10 nov,2016)
============================
- [Fix]: Live CSS for wp widget
- [Improved]: Nested shortcodes
- [Improved]: Compatible with KingComposer version 2.6

Version 1.5 / (28.9.2016)
============================
- [Improved]: Add copy/paste styling for all elements, rows, columns
- [Improved]: Css system live preview
- [Improved]: Live preview for some of core elements

Version 1.4 / (20.9.2016)
- [Improved] UI/UX
- [Fix] live changes for elements
				
Version 1.2 / (1.8.2016)
============================
- [New feature]: Right-click control panel 
- [New feature]: New feature copy/paste element style
- [New feature]: Responsive options 
- [New feature]: CSS Inspector
- [New feature]: New Sections system
- [New feature]: Resizable screen with in responsive mode
- [Improvement]: Cache for loading faster
- [Improvement]: Width of columns
- [Improvement]: All elements with new CSS system
- [Improvement]: Improve css border, allow set only top, right, bottom or left
- [Update]	: Prevent edit element in responsive mode
- [Update]	: Focus to CSS Editor in responsive mode
- [Update]	: Add & improve some of elements in core
- [Remove]	: Remove list element on the left side
- [Remove]	: Remove top elements breadcrumbs


Version 1.0 / (1.5.2016)
============================
- Initial release

